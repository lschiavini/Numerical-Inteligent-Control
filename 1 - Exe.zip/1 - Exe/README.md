# Numerical-Inteligent-Control
Repo for code built for the class during the semester
